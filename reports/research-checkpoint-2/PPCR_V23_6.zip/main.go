package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"os"
	"regexp"
	"sort"
)

const rootPin = "f0560b92eb9de5fd3cbcebc4479804c8bf974060ad52059a3afe7e829cbc9022"
const commitPin = "e6840ccdc8bbd61222c3f074065196e3c97000d757c4452aa1c24e105cc97e5c"
const domain = "PPCR-V23.5-RESEARCH-V1\x00"

type M = map[string]any

func ck(b bool, s string) {
	if !b {
		panic(s)
	}
}

var num = regexp.MustCompile(`^(0|[1-9][0-9]*)$`)
var addr = regexp.MustCompile(`^0x[0-9a-f]{40}$`)
var digest = regexp.MustCompile(`^[0-9a-f]{64}$`)

func ascii(s string) {
	for _, c := range s {
		ck(c >= 32 && c <= 126, "nonprintable/nonASCII")
	}
}
func read(d *json.Decoder) any {
	t, e := d.Token()
	ck(e == nil, "JSON token")
	switch v := t.(type) {
	case json.Delim:
		switch v {
		case '{':
			m := M{}
			for d.More() {
				k, e := d.Token()
				ck(e == nil, "key")
				s := k.(string)
				ascii(s)
				_, ok := m[s]
				ck(!ok, "duplicate key")
				m[s] = read(d)
			}
			t, e = d.Token()
			ck(e == nil && t == json.Delim('}'), "object close")
			return m
		case '[':
			a := []any{}
			for d.More() {
				a = append(a, read(d))
			}
			t, e = d.Token()
			ck(e == nil && t == json.Delim(']'), "array close")
			return a
		}
		panic("delimiter")
	case string:
		ascii(v)
	case json.Number:
		ck(num.MatchString(string(v)), "numeric token")
	case bool, nil:
	default:
		panic("type")
	}
	return t
}
func parse(b []byte) any {
	d := json.NewDecoder(bytes.NewReader(b))
	d.UseNumber()
	v := read(d)
	_, e := d.Token()
	ck(e == io.EOF, "trailing JSON")
	return v
}
func load(p string) M { b, e := os.ReadFile(p); ck(e == nil, "read "+p); return parse(b).(M) }
func canon(v any) []byte {
	var b bytes.Buffer
	e := json.NewEncoder(&b)
	e.SetEscapeHTML(false)
	ck(e.Encode(v) == nil, "encode")
	return bytes.TrimSuffix(b.Bytes(), []byte{10})
}
func eq(a, b any) bool { return bytes.Equal(canon(a), canon(b)) }
func hash(tag byte, parts ...[]byte) []byte {
	h := sha256.New()
	h.Write([]byte(domain))
	h.Write([]byte{tag})
	for _, p := range parts {
		h.Write(p)
	}
	return h.Sum(nil)
}
func u(n int) []byte                { b := make([]byte, 8); binary.BigEndian.PutUint64(b, uint64(n)); return b }
func leaf(i int, r M) []byte        { b := canon(r); return hash(0, u(i), u(len(b)), b) }
func envelope(c M, r []byte) []byte { b := canon(c); return hash(3, u(len(b)), b, r) }
func hx(b []byte) string            { return hex.EncodeToString(b) }
func decode(s string) []byte {
	ck(digest.MatchString(s), "digest format")
	b, e := hex.DecodeString(s)
	ck(e == nil, "hex")
	return b
}
func integer(v any) int {
	n, e := v.(json.Number).Int64()
	ck(e == nil && n >= 0 && n <= 1<<30, "integer")
	return int(n)
}
func money(v any) *big.Int {
	s := v.(string)
	ck(num.MatchString(s), "wei format")
	n, ok := new(big.Int).SetString(s, 10)
	ck(ok && n.BitLen() <= 256, "wei range")
	return n
}
func verify(r, p, c M, root, commit []byte) bool {
	defer func() { recover() }()
	i := integer(p["index"])
	ck(i < 585 && p["address"] == r["address"], "proof identity")
	ss := p["siblings"].([]any)
	ck(len(ss) == 10, "depth")
	v := leaf(i, r)
	for _, s := range ss {
		b := decode(s.(string))
		if i&1 == 1 {
			v = hash(1, b, v)
		} else {
			v = hash(1, v, b)
		}
		i >>= 1
	}
	return bytes.Equal(v, root) && bytes.Equal(envelope(c, root), commit) && hx(root) == rootPin && hx(commit) == commitPin
}
func clone(m M) M { return parse(canon(m)).(M) }
func rejected(f func()) (ok bool) {
	defer func() {
		if recover() != nil {
			ok = true
		}
	}()
	f()
	return false
}
func run() {
	b := load("ppcr_v23_5_bundle.json")
	ref := load("reference_report.json")
	c := b["context"].(M)
	ck(eq(c, ref["context"]) && ref["status"] == "PASS", "reference context")
	ck(b["treeRoot"] == rootPin && b["commitment"] == commitPin && ref["treeRoot"] == rootPin && ref["commitment"] == commitPin, "pins")
	ck(c["scope"] == "RESEARCH_EVIDENCE_ONLY" && c["eligibility"] == "NOT_DETERMINED" && c["authorization"] == "NOT_DETERMINED" && c["canonicality"] == "NOT_ATTESTED" && c["completeness"] == "NOT_ESTABLISHED", "scope")
	ck(integer(c["recordCount"]) == 585 && integer(c["quarantined"]) == 50 && integer(c["consistent"]) == 535, "context counts")
	rs := b["records"].([]any)
	ps := b["proofs"].([]any)
	ck(len(rs) == 585 && len(ps) == 585, "counts")
	tot := [3]*big.Int{new(big.Int), new(big.Int), new(big.Int)}
	qt := [3]*big.Int{new(big.Int), new(big.Int), new(big.Int)}
	q, native, old, controls := 0, 0, 0, 0
	prev := ""
	qs := map[string]bool{}
	levels := make([][]byte, 1024)
	for i, x := range rs {
		r := x.(M)
		a := r["address"].(string)
		ck(addr.MatchString(a) && a > prev, "address order")
		prev = a
		s := r["structuralRecord"].(M)
		ck(s["address"] == a && s["eligibility"] == "NOT_DETERMINED", "structural identity")
		flags := s["structural"].(M)["flags"].([]any)
		isq := s["classification"] == "QUARANTINE_REVIEW"
		ck(isq == (len(flags) > 0), "flags")
		if isq {
			q++
			qs[a] = true
		} else {
			ck(s["classification"] == "STRUCTURALLY_CONSISTENT", "class")
		}
		if s["population"] == "original" {
			old++
			ck(r["additionalProofSha256"] == nil, "original proof")
		} else {
			ck(s["population"] == "additional", "population")
			m := r["additionalProofSha256"].(M)
			for _, k := range []string{"pre", "post", "later"} {
				decode(m[k].(string))
			}
		}
		decode(r["discoveryProofSha256"].(string))
		ss := r["snapshots"].([]any)
		bal := s["balancesWei"].([]any)
		ck(len(ss) == 3 && len(bal) == 3 && bal[0] == bal[1], "snapshots")
		first := ss[0].(M)["account"].(M)
		for j, v := range ss {
			ac := v.(M)["account"].(M)
			ck(ac["balanceWei"] == bal[j], "balance")
			for _, k := range []string{"nonce", "storageRoot", "codeHash"} {
				ck(eq(ac[k], first[k]), "account invariant")
			}
			n := money(bal[j])
			tot[j].Add(tot[j], n)
			if isq {
				qt[j].Add(qt[j], n)
			}
		}
		obs := r["nativeObservations"].([]any)
		ck(isq == (len(obs) > 0) && isq == (r["nativeFixture"] != nil), "native coverage")
		seen := map[string]bool{}
		nc := 0
		for _, v := range obs {
			o := v.(M)
			k := fmt.Sprint(o["scenario"], ":", o["step"])
			ck(!seen[k], "duplicate observation")
			seen[k] = true
			ck(o["fixture"] == a && eq(o["issues"], flags) && o["population"] == s["population"] && o["codeUnchanged"] == true && o["ownershipSlotsUnchanged"] == true && o["traceObserved"] == true && integer(o["internalHits"]) == 1, "native invariant")
			if integer(o["scenario"]) == 0 {
				nc++
				controls++
				ck(o["internalResult"] == "0x0" && integer(o["storageWriteOpcodes"]) == 0, "control")
			}
			native++
		}
		if isq {
			ck(nc == 1, "control count")
		}
		levels[i] = leaf(i, r)
	}
	ck(q == 50 && old == 284 && native == 228 && controls == 50, "population totals")
	for j := 0; j < 3; j++ {
		ck(tot[j].String() == c["balancesWei"].([]any)[j] && qt[j].String() == c["quarantineBalancesWei"].([]any)[j], "accounting")
	}
	rr := c["classificationRefinements"].([]any)
	ck(len(rr) == 4, "refinements")
	for _, v := range rr {
		ck(qs[v.(M)["address"].(string)], "refinement quarantine")
	}
	for i := 585; i < 1024; i++ {
		levels[i] = hash(2, u(i))
	}
	for len(levels) > 1 {
		next := make([][]byte, len(levels)/2)
		for i := range next {
			next[i] = hash(1, levels[2*i], levels[2*i+1])
		}
		levels = next
	}
	root := levels[0]
	commit := envelope(c, root)
	ck(hx(root) == rootPin && hx(commit) == commitPin, "reconstruction")
	for i, v := range ps {
		p := v.(M)
		ck(integer(p["index"]) == i && verify(rs[i].(M), p, c, root, commit), "inclusion proof")
	}
	tests := 0
	r := rs[0].(M)
	p := ps[0].(M)
	reject := func(r, p, c M, rt, cm []byte) { ck(!verify(r, p, c, rt, cm), "negative accepted"); tests++ }
	for _, k := range []string{"address", "discoveryProofSha256"} {
		x := clone(r)
		x[k] = "bad"
		reject(x, p, c, root, commit)
	}
	for _, k := range []string{"classification", "eligibility", "balancesWei", "priorFlags"} {
		x := clone(r)
		x["structuralRecord"].(M)[k] = "bad"
		reject(x, p, c, root, commit)
	}
	for _, v := range []any{json.Number("1"), json.Number("585"), json.Number("-1")} {
		x := clone(p)
		x["index"] = v
		reject(r, x, c, root, commit)
	}
	x := clone(p)
	x["siblings"] = x["siblings"].([]any)[:9]
	reject(r, x, c, root, commit)
	x = clone(p)
	x["siblings"].([]any)[0] = fmt.Sprintf("%064x", 0)
	reject(r, x, c, root, commit)
	x = clone(p)
	x["address"] = "bad"
	reject(r, x, c, root, commit)
	for _, k := range []string{"chainId", "recordCount", "eligibility", "nativeCalls", "roots"} {
		x := clone(c)
		x[k] = "bad"
		reject(r, p, x, root, commit)
	}
	reject(r, p, c, make([]byte, 32), commit)
	reject(r, p, c, root, make([]byte, 32))
	reject(rs[1].(M), p, c, root, commit)
	for _, s := range []string{`{"a":1,"a":2}`, `1 2`, `-1`, `1.0`, `1e0`, `"\u0080"`, `"\n"`} {
		ck(rejected(func() { parse([]byte(s)) }), "parser accepted")
		tests++
	}
	ck(string(canon(parse([]byte(`{"z":1,"a":"<>&"}`)))) == `{"a":"<>&","z":1}`, "canonical encoding")
	tests++
	keys := []string{}
	for k, v := range c["inputSha256"].(M) {
		decode(v.(string))
		keys = append(keys, k)
	}
	sort.Strings(keys)
	ck(len(keys) == 11, "input pins")
	report := M{"status": "PASS", "scope": "RESEARCH_EVIDENCE_ONLY", "commitment": hx(commit), "treeRoot": hx(root), "proofsVerified": 585, "testsPassed": tests, "quarantined": q, "nativeCalls": native, "balancesWei": c["balancesWei"], "quarantineBalancesWei": c["quarantineBalancesWei"], "inputFingerprintsBound": len(keys), "eligibility": "NOT_DETERMINED", "limitations": []string{"Bundle-level verification; source inputs not reconstructed or raw trie proofs replayed", "Native observations not rerun", "Pinned commitment is research-only"}}
	out, e := json.MarshalIndent(report, "", "  ")
	ck(e == nil, "report encode")
	ck(os.WriteFile("ppcr_v23_6_report.json", append(out, 10), 0644) == nil, "report write")
	fmt.Println("V23_6_PASS", 585, tests, hx(commit))
	fmt.Println("TREE_ROOT", hx(root))
}
func main() {
	defer func() {
		if v := recover(); v != nil {
			fmt.Fprintln(os.Stderr, "V23_6_STOPPED_SAFELY", v)
			os.Exit(1)
		}
	}()
	run()
}
