PPCR V23.6 — independent Go bundle verifier
Run: go run main.go
Requires Go (tested Go 1.23.2 linux/amd64). Standard library only.
Inputs: ppcr_v23_5_bundle.json and reference_report.json (local V23.5 reproduction).
Output: ppcr_v23_6_report.json; nonzero exit on rejection.
The trusted root and commitment are hardcoded in main.go. JSON parsing rejects duplicate keys, trailing data, negative/fractional/exponent numeric tokens and nonprintable/non-ASCII strings. Canonical encoding uses sorted map keys and unescaped HTML characters. Rebuilds all 1024 leaves and verifies 585 inclusion paths; reconciles balances with big.Int, population, quarantine and native observation metadata. 20 proof mutation tests, seven parser rejection tests, one canonical encoding test.
Scope: verifies the already assembled V23.5 bundle; does not regenerate it from eleven underlying inputs, validate original input bytes or rerun trie proofs or Geth. Context fingerprints are bound by the pinned commitment. No eligibility, canonicality, authorization or consensus attestation. Keep activation disabled.
