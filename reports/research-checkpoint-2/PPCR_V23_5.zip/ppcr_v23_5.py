"""Research-only evidence commitment; Python standard library; no network."""
import hashlib,json,re,copy
from pathlib import Path
from collections import Counter,defaultdict
from pins import PINS
BASE=Path(__file__).resolve().parent
DOMAIN=b'PPCR-V23.5-RESEARCH-V1\0'
ROOTS={'pre':'0xb1f01f4c02cf90ffb4011de01da52c6681255654c8767f5b999c65fe1a61a53b','post':'0xbbe30a4416aa0f5ddc3d61e56b670565f6174513df3fb24525f7e2a5a7da9e1b','later':'0x59e252211d43a01f10a6d9e18dc94f7218a0dff7a9776fa70a67ac744c233bf4'}
def ck(x,msg):
 if not x: raise ValueError(msg)
def unique(pairs):
 d={}
 for k,v in pairs:
  ck(k not in d,'duplicate JSON key');d[k]=v
 return d
def valid(x):
 if isinstance(x,str):ck(all(32<=ord(c)<=126 for c in x),'nonprintable/nonASCII string')
 elif type(x) is int:ck(x>=0,'negative numeric token')
 elif x is None or type(x) is bool:pass
 elif isinstance(x,list):
  for v in x:valid(v)
 elif isinstance(x,dict):
  for k,v in x.items():valid(k);valid(v)
 else:raise ValueError('unsupported JSON type')
def canon(x):
 valid(x);return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def h(b):return hashlib.sha256(b).digest()
def u(n):return n.to_bytes(8,'big')
def leaf(i,r):
 b=canon(r);return h(DOMAIN+b'\0'+u(i)+u(len(b))+b)
def branch(l,r):return h(DOMAIN+b'\1'+l+r)
def pad(i):return h(DOMAIN+b'\2'+u(i))
def envelope(c,root):
 b=canon(c);return h(DOMAIN+b'\3'+u(len(b))+b+root)
def verify(r,p,c,root,commit):
 try:
  i=p['index'];n=c['recordCount'];ck(type(i) is int and 0<=i<n,'index');ck(p['address']==r['address'],'address');ck(len(p['siblings'])==(n-1).bit_length(),'depth');v=leaf(i,r)
  for s in p['siblings']:
   ck(re.fullmatch('[0-9a-f]{64}',s),'sibling');b=bytes.fromhex(s);v=branch(b,v) if i&1 else branch(v,b);i//=2
  return v==root and envelope(c,root)==commit
 except (ValueError,KeyError,TypeError,OverflowError):return False
def load(n):
 b=(BASE/n).read_bytes();ck(h(b).hex()==PINS[n],n+' SHA256');return json.loads(b,object_pairs_hook=unique)
def indexed(rows,key='address'):
 d={r[key]:r for r in rows};ck(len(d)==len(rows),'duplicate address');return d
def main():
 d={n:load(n) for n in PINS};s=d['structural.json'];native=d['native.json'];o=d['original.json'];a=indexed(s['records']);orig=indexed(o['records']); snaps=[indexed(d[k+'.json']['records']) for k in ROOTS];quar={k for k,r in a.items() if r['classification']=='QUARANTINE_REVIEW'};f=indexed(d['fixtures.json']['fixtures']);ck(len(a)==585 and len(orig)==284 and len(quar)==50 and set(f)==quar,'population');ck(native['status']==s['status']==o['status']=='PASS' and native['failedObservationChecks']==0 and native['fixtureSha256']==PINS['fixtures.json'],'native binding');ck(set(orig).isdisjoint(snaps[0]) and set(a)==set(orig)|set(snaps[0]),'population union');ck(set(d['discovery.json']['proofSha256'])==set(a),'discovery population');ck(o['roots']==ROOTS,'original roots')
 for k,m in zip(ROOTS,snaps):
  x=d[k+'.json'];y=d[k+'_replay.json'];ck(x['status']=='PASS_FULL' and y['status']=='PASS' and x['stateRoot']==y['stateRoot']==ROOTS[k] and x['manifest']==y['manifest'] and set(m)==set(snaps[0])==set(y['manifest']) and len(m)==301 and y['storageProofsVerified']==2808,'snapshot replay '+k)
 nr=defaultdict(list);seen=set()
 for r in native['rows']:
  key=(r['fixture'],r['scenario'],r['step']);ck(key not in seen and r['fixture'] in quar,'native identity');seen.add(key);ck(r['issues']==a[r['fixture']]['structural']['flags'] and r['population']==a[r['fixture']]['population'],'native flags');ck(r['codeUnchanged'] and r['ownershipSlotsUnchanged'] and r['traceObserved'] and r['internalHits']==1,'native invariant');nr[r['fixture']].append(r)
 ck(len(seen)==228 and set(nr)==quar,'native coverage');ck(sum(r['scenario']==0 for r in native['rows'])==50,'controls');ck(all(r['internalResult']=='0x0' and r['storageWriteOpcodes']==0 for r in native['rows'] if r['scenario']==0),'control results')
 records=[];tot=[0,0,0];qt=[0,0,0]
 for addr,r in sorted(a.items()):
  ck(re.fullmatch('0x[0-9a-f]{40}',addr) and r['eligibility']=='NOT_DETERMINED','record identity');old=addr in orig; ss=orig[addr]['snapshots'] if old else [m[addr] for m in snaps]; ac=[x['account'] for x in ss];b=[int(x['balanceWei']) for x in ac];ck(list(map(str,b))==r['balancesWei'] and b[0]==b[1],'balance reconciliation');ck(all(all(x[k]==ac[0][k] for k in ('nonce','storageRoot','codeHash')) for x in ac),'account invariant');ck(bool(r['structural']['flags'])==(addr in quar),'classification');ck(r['population']==('original' if old else 'additional'),'population');tot=[x+y for x,y in zip(tot,b)];qt=[x+y for x,y in zip(qt,b)] if addr in quar else qt
  records.append({'address':addr,'structuralRecord':r,'snapshots':ss,'nativeObservations':sorted(nr[addr],key=lambda x:(x['scenario'],x['step'])),'nativeFixture':f.get(addr),'discoveryProofSha256':d['discovery.json']['proofSha256'][addr],'additionalProofSha256':None if old else {k:d[k+'_replay.json']['manifest'][addr] for k in ROOTS}})
 ck(list(map(str,tot))==[s['historicalWei'],s['historicalWei'],s['laterWei']] and list(map(str,qt))==[s['quarantineHistoricalWei'],s['quarantineHistoricalWei'],s['quarantineLaterWei']],'totals');ck(len(s['classificationRefinements'])==4 and all(x['address'] in quar for x in s['classificationRefinements']),'refinements')
 c={'schema':'ppcr-v23.5-research-v1','chainId':1,'blocks':[4501968,4501969,26494170],'roots':ROOTS,'recordCount':585,'consistent':535,'quarantined':50,'balancesWei':list(map(str,tot)),'quarantineBalancesWei':list(map(str,qt)),'inputSha256':PINS,'originalEvidence':{k:o[k] for k in ('historicalArchiveSha256','laterArchiveSha256','inventorySha256','libraryProofSha256','candidateFingerprint')},'additionalArchiveSha256':{k:d[k+'_replay.json']['archiveSha256'] for k in ROOTS},'discoveryArchiveSha256':d['discovery.json']['archiveSha256'],'classificationRefinements':s['classificationRefinements'],'nativeCalls':228,'nativeLimitations':native['limitations'],'eligibility':'NOT_DETERMINED','canonicality':'NOT_ATTESTED','completeness':'NOT_ESTABLISHED','authorization':'NOT_DETERMINED','unresolved':o['unresolved'],'scope':'RESEARCH_EVIDENCE_ONLY'}
 levels=[[leaf(i,r) for i,r in enumerate(records)]+[pad(i) for i in range(585,1024)]]
 while len(levels[-1])>1:
  l=levels[-1];levels.append([branch(l[i],l[i+1]) for i in range(0,len(l),2)])
 root=levels[-1][0];commit=envelope(c,root);proofs=[]
 for i,r in enumerate(records):
  p={'address':r['address'],'index':i,'siblings':[l[(i>>j)^1].hex() for j,l in enumerate(levels[:-1])]};ck(verify(r,p,c,root,commit),'proof');proofs.append(p)
 r=records[0];p=proofs[0];tests=0
 def reject(rr=r,pp=p,cc=c,rt=root,cm=commit):
  nonlocal tests
  ck(not verify(rr,pp,cc,rt,cm),'negative accepted');tests+=1
 for path,val in [('address','0x'+'0'*40),('discoveryProofSha256','0'*64)]:
  x=copy.deepcopy(r);x[path]=val;reject(rr=x)
 for key,val in [('classification','OTHER'),('eligibility','ELIGIBLE'),('balancesWei',['0','0','0']),('priorFlags',['OTHER'])]:
  x=copy.deepcopy(r);x['structuralRecord'][key]=val;reject(rr=x)
 for key,val in [('index',1),('index',585),('index',-1),('siblings',p['siblings'][:-1]),('siblings',['00'*32]+p['siblings'][1:]),('address','other')]:
  x=copy.deepcopy(p);x[key]=val;reject(pp=x)
 for key,val in [('chainId',2),('recordCount',584),('eligibility','ELIGIBLE'),('nativeCalls',229),('roots',{**ROOTS,'pre':'0x'+'0'*64})]:
  x=copy.deepcopy(c);x[key]=val;reject(cc=x)
 reject(rt=bytes(32));reject(cm=bytes(32));reject(rr=records[1]);ck(canon({'z':1,'a':2})==canon({'a':2,'z':1}),'canonical order');tests+=1
 bundle={'context':c,'treeRoot':root.hex(),'commitment':commit.hex(),'records':records,'proofs':proofs};report={'status':'PASS','scope':c['scope'],'recordCount':585,'proofsVerified':585,'treeLeaves':1024,'paddingLeaves':439,'proofDepth':10,'testsPassed':tests,'treeRoot':root.hex(),'commitment':commit.hex(),'context':c}
 for name,obj in [('ppcr_v23_5_bundle.json',bundle),('ppcr_v23_5_report.json',report)]: (BASE/name).write_bytes(json.dumps(obj,sort_keys=True,indent=2).encode('ascii')+b'\n')
 print('V23_5_PASS',585,tests,commit.hex());print('TREE_ROOT',root.hex())
if __name__=='__main__':main()
