import json, sys, hashlib
from pathlib import Path
MASK=(1<<64)-1
RC=[0x1,0x8082,0x800000000000808a,0x8000000080008000,0x808b,0x80000001,0x8000000080008081,0x8000000000008009,0x8a,0x88,0x80008009,0x8000000a,0x8000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x80000001,0x8000000080008008]
ROT=[0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14]
def require(ok):
    if not ok: raise ValueError('verification failed')
def rol(x,n): return ((x<<n)|(x>>(64-n)))&MASK
def keccak(data):
    a=[0]*25; p=bytearray(data); p.append(1); p.extend(bytes((-len(p))%136)); p[-1]|=128
    for off in range(0,len(p),136):
        for i in range(17): a[i]^=int.from_bytes(p[off+8*i:off+8*i+8],'little')
        for rc in RC:
            c=[a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20] for x in range(5)]
            d=[c[(x-1)%5]^rol(c[(x+1)%5],1) for x in range(5)]
            b=[0]*25
            for y in range(5):
                for x in range(5): b[y+5*((2*x+3*y)%5)]=rol(a[x+5*y]^d[x],ROT[x+5*y])
            a=[b[x+5*y]^((~b[(x+1)%5+5*y])&b[(x+2)%5+5*y]) for y in range(5) for x in range(5)]; a[0]^=rc
    return b''.join(x.to_bytes(8,'little') for x in a)[:32]
def decode(data):
    def one(i):
        require(i<len(data)); t=data[i]; i+=1
        if t<128:return bytes([t]),i
        islist=t>=192; base=192 if islist else 128; n=t-base
        if n>55:
            k=n-55; require(i+k<=len(data) and data[i]!=0); n=int.from_bytes(data[i:i+k],'big'); i+=k; require(n>=56)
        end=i+n; require(end<=len(data))
        if not islist:
            require(n!=1 or data[i]>=128); return data[i:end],end
        out=[]
        while i<end:
            v,i=one(i);out.append(v)
        require(i==end);return out,end
    v,i=one(0);require(i==len(data));return v
def hx(s): require(s.startswith('0x'));return bytes.fromhex(s[2:])
def nib(b):return [int(x,16) for x in b.hex()]
def verify(root,addr,nodes):
    require(len(root)==32 and len(addr)==20); db={keccak(n):n for n in nodes}; path=nib(keccak(addr)); ref=root
    for _ in range(65):
        if isinstance(ref,list): node=ref
        else:
            require(len(ref)==32 and ref in db); node=decode(db[ref])
        require(isinstance(node,list))
        if len(node)==17:
            if not path: value=node[16];break
            ref=node[path.pop(0)]
        elif len(node)==2:
            require(isinstance(node[0],bytes) and len(node[0])>0); k=nib(node[0]); flag=k[0];require(flag<4 and (flag%2 or k[1]==0)); k=k[1:] if flag%2 else k[2:];require(path[:len(k)]==k);path=path[len(k):]
            if flag>=2:require(not path);value=node[1];break
            require(k);ref=node[1]
        else:raise ValueError('bad node')
    else:raise ValueError('path too long')
    require(isinstance(value,bytes) and value); f=decode(value);require(isinstance(f,list) and len(f)==4 and all(isinstance(x,bytes) for x in f));n,b,s,c=f;require(not n.startswith(b'\0') and not b.startswith(b'\0') and len(s)==len(c)==32)
    return dict(nonce=int.from_bytes(n,'big'),balanceWei=str(int.from_bytes(b,'big')),storageRoot='0x'+s.hex(),codeHash='0x'+c.hex())
ROOTS={'pre':'0xb1f01f4c02cf90ffb4011de01da52c6681255654c8767f5b999c65fe1a61a53b','post':'0xbbe30a4416aa0f5ddc3d61e56b670565f6174513df3fb24525f7e2a5a7da9e1b'}
WALLETS={'0x0285d5528f574f1361009eef75a4f61942767799':'44433042000000000','0x038422e0057c4df8460b73920f28426b8f6cd452':'0','0x043dae09e7f51d02b8745bcf82c4c5ee86e4bc96':'360000000000000000000'}
def main():
    require(keccak(b'').hex()=='c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470');require(keccak(b'abc').hex()=='4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45')
    raw=Path(sys.argv[1]).read_bytes(); report=json.loads(raw); seen=set(); results=[]
    for r in report['records']:
        label,addr=r['snapshot'],r['address'];require((label,addr) not in seen and addr in WALLETS);seen.add((label,addr));root=hx(ROOTS[label]);p=r['proof'];nodes=[hx(x) for x in p['accountProof']];v=verify(root,hx(addr),nodes);require(v==r['proven'] and v['balanceWei']==WALLETS[addr] and v['codeHash']=='0x5d85058ca470c3561426ba7b1675197b2aa848173843dc79d36e3ec14ce91eeb');require(p['address']==addr and int(p['nonce'],16)==v['nonce'] and int(p['balance'],16)==int(v['balanceWei']) and p['storageHash']==v['storageRoot'] and p['codeHash']==v['codeHash'])
        for rr,aa,nn in [(bytes([root[0]^1])+root[1:],hx(addr),nodes),(root,hx(addr),[bytes([nodes[0][0]^1])+nodes[0][1:]]+nodes[1:]),(root,bytes([hx(addr)[0]^1])+hx(addr)[1:],nodes)]:
            try:verify(rr,aa,nn)
            except (ValueError,IndexError):pass
            else:raise ValueError('negative control accepted')
        results.append(dict(snapshot=label,address=addr,proven=v,negativeControls=3,status='PASS'));print(label,addr,'PASS')
    require(seen=={(s,a) for s in ROOTS for a in WALLETS});out=dict(inputSha256=hashlib.sha256(raw).hexdigest(),roots=ROOTS,records=results,status='PASS',canonicality='NOT_ATTESTED',eligibility='NOT_DETERMINED');Path('ppcr_v22_0_offline_replay.json').write_text(json.dumps(out,indent=2)+'\n');print('OFFLINE_REPLAY_PASS')
if __name__=='__main__':main()
