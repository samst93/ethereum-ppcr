import unittest,copy,json
from pathlib import Path
import scan as s
class Absence(unittest.TestCase):
    def test_saved(self):
        for p in json.loads(Path('absence_fixtures.json').read_text()):
            a=p['address'];self.assertEqual(s.verify(a,p)['classification'],'AUTHENTICATED_ABSENT')
            for k,v in [('nonce','0x1'),('balance','0x1'),('codeHash',s.EMPTY_CODE),('storageHash',s.EMPTY_TRIE),('codeHash',s.TARGET)]:
                q=copy.deepcopy(p);q[k]=v;self.assertRaises(ValueError,s.verify,a,q)
            q=copy.deepcopy(p);q['accountProof'].pop();self.assertRaises(ValueError,s.verify,a,q)
            self.assertRaises(ValueError,s.verify,a,p,'0x'+'00'*32)
    def test_inclusion_not_absence(self):
        p=json.loads(Path('fixture.json').read_text());p.update(nonce='0x0',balance='0x0',codeHash='0x'+'00'*32,storageHash='0x'+'00'*32);self.assertRaises(ValueError,s.verify,p['address'],p)
if __name__=='__main__':unittest.main(verbosity=2)
