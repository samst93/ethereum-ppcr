import copy,json,unittest
from pathlib import Path
import scan as s
class ProofTests(unittest.TestCase):
    def setUp(self):self.p=json.loads((s.BASE/'fixture.json').read_text());self.a=self.p['address']
    def test_historical(self):self.assertEqual(s.verify(self.a,self.p)['classification'],'EXACT_RUNTIME_MATCH')
    def test_keccak(self):self.assertEqual(s.EMPTY_CODE,'0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470')
    def test_wrong_root(self):self.assertRaises(ValueError,s.verify,self.a,self.p,'0x'+'00'*32)
    def test_missing_node(self):self.p['accountProof'].pop();self.assertRaises(ValueError,s.verify,self.a,self.p)
    def test_tampered_node(self):n=self.p['accountProof'][0];self.p['accountProof'][0]=n[:-2]+('00' if n[-2:]!='00' else '01');self.assertRaises(ValueError,s.verify,self.a,self.p)
    def test_duplicate(self):self.p['accountProof'].append(self.p['accountProof'][0]);self.assertRaises(ValueError,s.verify,self.a,self.p)
    def test_extra(self):self.p['accountProof'].append('0x80');self.assertRaises(ValueError,s.verify,self.a,self.p)
    def test_wrong_address(self):self.assertRaises(ValueError,s.verify,'0x'+'00'*20,self.p)
    def test_fields(self):
        for field,value in [('balance','0x0'),('nonce','0x0'),('codeHash',s.EMPTY_CODE),('storageHash',s.EMPTY_TRIE),('storageProof',[{}])]:
            with self.subTest(field=field):p=copy.deepcopy(self.p);p[field]=value;self.assertRaises(ValueError,s.verify,self.a,p)
    def synthetic(self,code):
        a='0x'+'12'*20;k=s.keccak(s.hx(a));leaf=s.enc([b'\x20'+k,s.enc([b'\x01',b'',s.hx(s.EMPTY_TRIE),s.hx(code)])]);root='0x'+s.keccak(leaf).hex();p={'address':a,'accountProof':['0x'+leaf.hex()],'nonce':'0x1','balance':'0x0','storageHash':s.EMPTY_TRIE,'codeHash':code,'storageProof':[]};return a,p,root
    def test_nonmatch(self):a,p,r=self.synthetic(s.EMPTY_CODE);self.assertEqual(s.verify(a,p,r)['classification'],'AUTHENTICATED_NONMATCH')
    def test_absence(self):a,p,r=self.synthetic(s.TARGET);a='0x'+'13'*20;p.update(address=a,nonce='0x0',codeHash=s.EMPTY_CODE);self.assertEqual(s.verify(a,p,r)['classification'],'AUTHENTICATED_ABSENT')
    def test_false_absence(self):a,p,r=self.synthetic(s.TARGET);p.update(nonce='0x0',codeHash=s.EMPTY_CODE);self.assertRaises(ValueError,s.verify,a,p,r)
    def test_empty_trie(self):a,p,r=self.synthetic(s.TARGET);p.update(accountProof=[],nonce='0x0',codeHash=s.EMPTY_CODE);self.assertEqual(s.verify(a,p,s.EMPTY_TRIE)['classification'],'AUTHENTICATED_ABSENT')
    def test_budget_zero(self):
        from unittest.mock import patch
        with patch.dict('os.environ',{'ETH_RPC_URL':'https://example.com'}):r=s.RPC(0);self.assertRaises(ValueError,r.call,'eth_chainId',[]);self.assertEqual(r.used,0)
if __name__=='__main__':unittest.main(verbosity=2)
