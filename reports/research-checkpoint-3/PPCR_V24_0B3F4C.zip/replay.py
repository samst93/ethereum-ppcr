import argparse,io,json,sqlite3,zipfile,tempfile
from pathlib import Path
from collections import Counter
from contextlib import ExitStack, closing
from functools import lru_cache
import scan as s
EXPECTED='b9f92d46050390a07df6a5486690058bf0ecb943983257ea26a167792fe132a6'
MISSING={'0x366791c61d94839e2050ed34bed82d7abba5e85a','0x5a2c3a454cddd948381363e2ea15962735c0093f','0xb1cf4fc1cd37f3d66fc4c3b5c66a9576c7b85b3d'}
def read_member(z, name):
    canonical = name.replace(chr(92), '/')
    matches = [i for i in z.infolist() if i.filename.replace(chr(92), '/') == canonical]
    s.ck(len(matches) == 1, 'missing or ambiguous ZIP member: ' + canonical)
    return z.read(matches[0])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--archive',required=True);args=ap.parse_args()
    raw=Path(args.archive).read_bytes();s.ck(s.sha(raw)==EXPECTED,'input archive fingerprint mismatch')
    popraw=(s.BASE/'population.json').read_bytes();pop=json.loads(popraw);known=set(pop['known']);addresses=set(pop['addresses']);control=json.loads((s.BASE/'fixture.json').read_text())['address'];s.ck(len(addresses)==5976 and len(known)==585 and control in known and control not in addresses,'population mismatch')
    s.keccak=lru_cache(maxsize=20000)(s.keccak)
    with tempfile.TemporaryDirectory() as td,zipfile.ZipFile(io.BytesIO(raw)) as z, ExitStack() as resources:
        s.ck(z.testzip() is None,'outer CRC');q=resources.enter_context(zipfile.ZipFile(io.BytesIO(read_member(z,'PPCR_V24_0B3F1_EVIDENCE.zip'))));s.ck(q.testzip() is None and q.read('population.json')==popraw,'inner integrity');path=Path(td)/'proofs.sqlite';path.write_bytes(q.read('proofs.sqlite'));db=resources.enter_context(closing(sqlite3.connect(path)));s.ck(db.execute('pragma integrity_check').fetchone()==('ok',),'database integrity')
        meta=s.pack({'root':s.ROOT,'target':s.TARGET,'population':s.sha(popraw),'schema':1});s.ck(db.execute("select v from meta where k='context'").fetchone()==(meta,),'context mismatch');s.ck(set(a for a, in db.execute('select address from proofs'))==(addresses|{control})-MISSING,'checkpoint population mismatch')
        for a in sorted(MISSING):
            p=json.loads(read_member(z,'retry_diagnostics/'+a+'.json'));s.ck(s.verify(a,p)=={'classification':'AUTHENTICATED_ABSENT','account':None},'unexpected recovered classification');t=s.pack(p);db.execute('insert into proofs values (?,?,?)',(a,t,s.sha(t.encode())))
        db.commit();rows=[];nodes=0
        for i,(a,t,d) in enumerate(db.execute('select address,proof,digest from proofs order by address'),1):
            s.ck(s.sha(t.encode())==d,'proof fingerprint mismatch');p=json.loads(t);v=s.verify(a,p);nodes+=len(p['accountProof']);s.ck(a!=control or v['classification']=='EXACT_RUNTIME_MATCH','control mismatch');rows.append({'address':a,'control':a==control,'proofSha256':d,**v})
            if i%1000==0:print('REPLAYED',i,flush=True)
        db.close();s.ck(set(r['address'] for r in rows)==addresses|{control},'coverage mismatch');counts=Counter(r['classification'] for r in rows if not r['control']);matches=[r['address'] for r in rows if not r['control'] and r['classification']=='EXACT_RUNTIME_MATCH'];report={'stage':'V24.0B3F4B','status':'PASS_OFFLINE_AUTHENTICATED_POPULATION','referenceBlock':s.BLOCK,'referenceRoot':s.ROOT,'targetCodeHash':s.TARGET,'inputSha256':EXPECTED,'populationSha256':s.sha(popraw),'discoveryCount':len(addresses),'knownCount':len(known),'inventoryOverlap':len(addresses&known),'proofsReplayed':len(rows),'proofNodeOccurrences':nodes,'recovered':sorted(MISSING),'counts':dict(counts),'exactMatches':matches,'newExactMatches':sorted(set(matches)-known),'rpcRequests':0,'canonicality':'NOT_ATTESTED','completeness':'NOT_ESTABLISHED','eligibility':'NOT_DETERMINED','rows':rows}
        b=(s.pack(report)+'\n').encode();Path('ppcr_v24_0b3f4b_report.json').write_bytes(b)
        with zipfile.ZipFile('PPCR_V24_0B3F4B_EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as out:out.writestr('ppcr_v24_0b3f4b_report.json',b);out.write(path,'proofs.sqlite');out.writestr('population.json',popraw)
        print(report['status'],len(rows),dict(counts),nodes,flush=True)
if __name__=='__main__':main()
