import io, unittest, zipfile
from replay import read_member
class Paths(unittest.TestCase):
    def check(self, names, expected):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            for n in names: z.writestr(n,b'proof')
        with zipfile.ZipFile(b) as z:
            if expected: self.assertEqual(read_member(z,'retry_diagnostics/a.json'),b'proof')
            else: self.assertRaises(ValueError,read_member,z,'retry_diagnostics/a.json')
    def test_backslash(self): self.check(['retry_diagnostics\\a.json'],True)
    def test_forward_slash(self): self.check(['retry_diagnostics/a.json'],True)
    def test_ambiguous(self): self.check(['retry_diagnostics\\a.json','retry_diagnostics/a.json'],False)
    def test_missing(self): self.check(['other/a.json'],False)
if __name__=='__main__': unittest.main(verbosity=2)
