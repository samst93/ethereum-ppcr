"""Read-only PPCR account proof research scanner; Python 3.9+, no dependencies."""
import argparse, hashlib, json, os, re, sqlite3, time, urllib.request, urllib.parse, zipfile
from pathlib import Path
from primitives import keccak, decode, nib
BASE=Path(__file__).resolve().parent
ROOT='0xb1f01f4c02cf90ffb4011de01da52c6681255654c8767f5b999c65fe1a61a53b'
HEADER='0xfa31f3dc57eddd5e481406b66b92d0968a6cec8f27bb459db9b8e97a5731ac91'
TARGET='0x5d85058ca470c3561426ba7b1675197b2aa848173843dc79d36e3ec14ce91eeb'
BLOCK=4501968
EMPTY_CODE='0x'+keccak(b'').hex(); EMPTY_TRIE='0x'+keccak(b'\x80').hex()
def ck(ok,msg):
    if not ok: raise ValueError(msg)
def hx(s,n=None):
    ck(isinstance(s,str) and re.fullmatch(r'0x(?:[0-9a-fA-F]{2})*',s) is not None,'invalid hex data'); b=bytes.fromhex(s[2:]);ck(n is None or len(b)==n,'invalid data length');return b
def qty(s):
    ck(isinstance(s,str) and re.fullmatch(r'0x(?:0|[1-9a-fA-F][0-9a-fA-F]*)',s) is not None,'invalid quantity');return int(s,16)
def pack(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):
    if isinstance(x,list): b=b''.join(map(enc,x));base=192
    else:
        b=x;base=128
        if len(b)==1 and b[0]<128:return b
    if len(b)<56:return bytes([base+len(b)])+b
    n=len(b).to_bytes((len(b).bit_length()+7)//8,'big');return bytes([base+55+len(n)])+n+b
def path_value(root,key,nodes):
    ck(len(root)==len(key)==32,'root/key length');ck(len(nodes)<=65 and all(0<len(n)<=65536 for n in nodes),'proof limits')
    if root==hx(EMPTY_TRIE):ck(nodes in ([],[b'\x80']),'empty trie proof');return None
    db={keccak(n):n for n in nodes};ck(len(db)==len(nodes),'duplicate proof node');used=set();path=nib(key);ref=root
    def finish(v):
        ck(used==set(db),'unused proof nodes');return v
    for depth in range(65):
        if isinstance(ref,list):ck(len(enc(ref))<32,'oversized embedded node');node=ref
        else:
            ck(isinstance(ref,bytes) and len(ref)==32 and ref in db,'missing referenced node');raw=db[ref];ck(depth==0 or len(raw)>=32,'hashed short node');used.add(ref);node=decode(raw);ck(enc(node)==raw,'noncanonical RLP')
        ck(isinstance(node,list),'invalid node')
        if len(node)==17:
            ck(path and node[16]==b'','invalid secure branch');ref=node[path.pop(0)]
            if ref==b'':return finish(None)
        elif len(node)==2:
            ck(isinstance(node[0],bytes) and node[0],'invalid compact path');p=nib(node[0]);f=p[0];ck(f<4 and (f%2 or p[1]==0),'invalid compact flags');p=p[1:] if f%2 else p[2:]
            ck(len(p)<=len(path) and (f<2 or len(p)==len(path)),'invalid secure path length')
            if f<2:ck(p and len(p)<len(path),'invalid extension')
            else:ck(isinstance(node[1],bytes) and node[1],'invalid leaf')
            if path[:len(p)]!=p:return finish(None)
            path=path[len(p):]
            if f>=2:return finish(node[1])
            ref=node[1]
        else:raise ValueError('invalid node arity')
    raise ValueError('trie depth exceeded')
def verify(address,p,root=ROOT):
    ck(hx(p['address'],20)==hx(address,20),'address mismatch');ck(p['storageProof']==[],'unexpected storage proofs')
    raw=path_value(hx(root,32),keccak(hx(address,20)),[hx(n) for n in p['accountProof']]); nonce=qty(p['nonce']);balance=qty(p['balance']);storage=hx(p['storageHash'],32);code=hx(p['codeHash'],32)
    if raw is None:
        ck(nonce==balance==0 and (storage,code) in ((hx(EMPTY_TRIE),hx(EMPTY_CODE)),(bytes(32),bytes(32))),'absence fields mismatch');return {'classification':'AUTHENTICATED_ABSENT','account':None}
    f=decode(raw);ck(isinstance(f,list) and len(f)==4 and all(isinstance(x,bytes) for x in f),'invalid account RLP');n,b,s,c=f;ck(len(n)<=8 and len(b)<=32 and not n.startswith(b'\0') and not b.startswith(b'\0') and len(s)==len(c)==32,'invalid account fields');ck((int.from_bytes(n,'big'),int.from_bytes(b,'big'),s,c)==(nonce,balance,storage,code),'RPC account fields disagree')
    return {'classification':'EXACT_RUNTIME_MATCH' if code==hx(TARGET) else 'AUTHENTICATED_NONMATCH','account':{'nonce':nonce,'balanceWei':str(balance),'storageRoot':'0x'+storage.hex(),'codeHash':'0x'+code.hex()}}
class RPC:
    def __init__(self,limit):
        self.url=os.environ.get('ETH_RPC_URL','');u=urllib.parse.urlsplit(self.url);ck(u.scheme=='https' and u.hostname and not any(c.isspace() for c in self.url),'HTTPS RPC required');self.used=0;self.limit=limit
    def call(self,m,p):
        ck(self.used<self.limit,'request budget exhausted');self.used+=1;req=urllib.request.Request(self.url,pack({'jsonrpc':'2.0','id':self.used,'method':m,'params':p}).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=60) as r: raw=r.read(8*1024*1024+1)
        ck(len(raw)<=8*1024*1024,'response too large');v=json.loads(raw);ck(v.get('id')==self.used and v.get('jsonrpc')=='2.0' and 'error' not in v and v.get('result') is not None,'RPC envelope failure');return v['result']
    def anchor(self):
        ck(qty(self.call('eth_chainId',[]))==1,'wrong chain');h=self.call('eth_getBlockByNumber',[hex(BLOCK),False]);ck(qty(h['number'])==BLOCK and h['hash']==HEADER and h['stateRoot']==ROOT,'reference header mismatch')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int,default=25);ap.add_argument('--budget',type=int,default=28);ap.add_argument('--db',default='proofs.sqlite');ap.add_argument('--offline',action='store_true');args=ap.parse_args();ck(1<=args.limit<=5976 and 0<=args.budget<=6000,'invalid limits')
    raw=(BASE/'population.json').read_bytes();pop=json.loads(raw);a=pop['addresses'];known=set(pop['known']);ck(len(a)==len(set(a))==5976 and a==sorted(a) and len(known)==585,'population invalid');[hx(x,20) for x in a+list(known)];control=json.loads((BASE/'fixture.json').read_text())['address'];ck(control in known and control not in a,'control invalid')
    # Deterministic spread across sorted address population; 25 first, then nested expansion.
    order=sorted(a,key=lambda x:sha(b'PPCR-V24.0B3F1\0'+hx(x)))
    selected=order[:args.limit];alladdr=[control]+selected;db=sqlite3.connect(args.db);db.execute('CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY,v TEXT)');db.execute('CREATE TABLE IF NOT EXISTS proofs (address TEXT PRIMARY KEY, proof TEXT NOT NULL, digest TEXT NOT NULL)');meta=pack({'root':ROOT,'target':TARGET,'population':sha(raw),'schema':1});old=db.execute("SELECT v FROM meta WHERE k='context'").fetchone();ck(old is None or old[0]==meta,'checkpoint context mismatch');db.execute('INSERT OR IGNORE INTO meta VALUES (?,?)',('context',meta));db.commit();rpc=None;rows=[];fail=[];stop=None
    try:
        if not args.offline:rpc=RPC(args.budget);rpc.anchor()
        for addr in alladdr:
            try:
                cached=db.execute('SELECT proof,digest FROM proofs WHERE address=?',(addr,)).fetchone()
                if cached:
                    text,digest=cached;ck(sha(text.encode())==digest,'checkpoint fingerprint mismatch');p=json.loads(text)
                else:
                    ck(rpc is not None,'missing offline proof');p=rpc.call('eth_getProof',[addr,[],hex(BLOCK)]);text=pack(p);digest=sha(text.encode())
                result=verify(addr,p);ck(addr!=control or result['classification']=='EXACT_RUNTIME_MATCH','positive control mismatch')
                if not cached:db.execute('INSERT INTO proofs VALUES (?,?,?)',(addr,text,digest));db.commit()
                rows.append({'address':addr,'control':addr==control,'knownInventory':addr in known,'cached':bool(cached),'proofSha256':digest,**result});print(addr,result['classification'],flush=True)
            except Exception as e:
                fail.append({'address':addr,'errorType':type(e).__name__,'httpStatus':getattr(e,'code',None) if isinstance(getattr(e,'code',None),int) else None});print(addr,'UNRESOLVED',type(e).__name__,flush=True)
                if addr==control:break
    except Exception as e:stop=type(e).__name__
    done={r['address'] for r in rows};missing=[x for x in alladdr if x not in done];matches=[r['address'] for r in rows if not r['control'] and r['classification']=='EXACT_RUNTIME_MATCH'];report={'stage':'V24.0B3F1','status':'PASS_BOUNDED_AUTHENTICATED_SAMPLE' if not missing and not stop else 'PARTIAL_OR_BLOCKED','referenceBlock':BLOCK,'referenceRoot':ROOT,'targetCodeHash':TARGET,'populationSha256':sha(raw),'discoverySha256':pop['discoverySha256'],'inventoryOverlap':len(set(a)&known),'selected':selected,'control':control,'rows':rows,'failures':fail,'missing':missing,'exactMatches':matches,'requests':rpc.used if rpc else 0,'budget':args.budget,'stopReason':stop,'canonicality':'NOT_ATTESTED','completeness':'NOT_ESTABLISHED','eligibility':'NOT_DETERMINED'}
    out=Path('ppcr_v24_0b3f1_report.json');out.write_text(pack(report)+'\n',encoding='utf-8');db.close()
    with zipfile.ZipFile('PPCR_V24_0B3F1_EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.write(out,out.name);z.write(args.db,'proofs.sqlite');z.write(BASE/'population.json','population.json')
    print(report['status'],len(rows),report['requests'],flush=True);return int(bool(missing or stop))
if __name__=='__main__':raise SystemExit(main())
