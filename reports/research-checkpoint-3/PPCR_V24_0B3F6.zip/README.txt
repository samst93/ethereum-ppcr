PPCR V24.0B3F6 — research evidence only
Python 3 standard library. No RPC or network access required.
Run python -u commit.py from this directory. It verifies pinned source bytes,
all 585 previous Merkle membership proofs and all 6561 new membership proofs,
and runs 32 negative membership tests. Output: ppcr_v24_0b3f6_report.json and
ppcr_v24_0b3f6_bundle.json. The source reports are included under short names.
The original V23.5 records are preserved in full inside the new records.
The known-wallet positive control is bound in context, not a duplicate leaf.
This commits to decoded evidence, including individual proof fingerprints;
it does not replay raw Ethereum trie proofs or prove discovery completeness.
Canonical encoding: printable ASCII strings, nonnegative integers, booleans,
null, arrays and objects; sorted keys, compact JSON, ASCII encoding.
Domain D = ASCII PPCR-V24.0B3F6-RESEARCH-V1 followed by a NUL byte.
H = SHA-256; u = unsigned 64-bit big-endian integer encoding.
Sort records by lowercase address. Leaf = H(D || 0x00 || u(index) ||
u(len(canonical record)) || canonical record). Padding = H(D || 0x02 || u(index)).
Branch = H(D || 0x01 || left || right). Pad to next power of two.
Commitment = H(D || 0x03 || u(len(canonical context)) || canonical context || root).
Proof siblings are bottom-up; index parity determines left/right order.
Verify against an independently trusted commitment; bundle alone is not trust.
Original V23.5 proofs use the original V23.5 domain and original context.
Canonicality, completeness, eligibility and authorization remain unresolved.
No consensus activation or state changes. Keep Geth activation disabled.
