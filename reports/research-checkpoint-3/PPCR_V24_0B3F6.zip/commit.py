"""Bounded research evidence commitment, not a consensus or eligibility root."""
import copy,json,re
from collections import Counter
from pathlib import Path
import merkle as m
BASE=Path(__file__).resolve().parent
PRIOR='e6840ccdc8bbd61222c3f074065196e3c97000d757c4452aa1c24e105cc97e5c'
DOMAIN=b'PPCR-V24.0B3F6-RESEARCH-V1\0'
TARGET='0x5d85058ca470c3561426ba7b1675197b2aa848173843dc79d36e3ec14ce91eeb'
ROOT=m.ROOTS['pre']
ck=m.ck
PINS=json.loads((BASE/'pins.json').read_text())
def load(n):
 b=(BASE/n).read_bytes();ck(m.h(b).hex()==PINS[n],n+' fingerprint');return json.loads(b,object_pairs_hook=m.unique)
def index(rows):
 d={r['address']:r for r in rows};ck(len(d)==len(rows) and all(re.fullmatch('0x[0-9a-f]{40}',a) for a in d),'address uniqueness');return d
def main():
 p,e,d,pop=map(load,['prior.json','exclusions.json','discovery.json','population.json'])
 ck(p['commitment']==PRIOR and p['context']['roots']['pre']==ROOT,'prior commitment context')
 known=index(p['records']);oldproof=index(p['proofs']);ck(len(known)==585 and set(known)==set(oldproof),'prior coverage')
 for a,r in known.items():ck(m.verify(r,oldproof[a],p['context'],bytes.fromhex(p['treeRoot']),bytes.fromhex(PRIOR)),'prior membership')
 ck(e['referenceRoot']==ROOT and e['referenceBlock']==4501968 and e['targetCodeHash']==TARGET and e['status']=='PASS_OFFLINE_AUTHENTICATED_POPULATION','reference')
 ck(e['populationSha256']==PINS['population.json'] and pop['discoverySha256']==PINS['discovery.json'],'population provenance')
 rows=index(e['rows']);controls=[r for r in rows.values() if r['control'] is True];ck(len(controls)==1,'control count');control=controls[0];a=control['address'];ck(a in known and control['classification']=='EXACT_RUNTIME_MATCH' and control['account']==known[a]['snapshots'][0]['account'],'positive control')
 excluded={a:r for a,r in rows.items() if r['control'] is False};ck(len(rows)==5977 and len(excluded)==5976 and not set(excluded)&set(known),'disjoint populations')
 ck(set(excluded)==set(d['addresses'])==set(pop['addresses']) and len(d['addresses'])==len(pop['addresses'])==5976 and set(known)==set(pop['known']) and len(pop['known'])==585,'population coverage')
 counts=Counter();balance=0
 for r in excluded.values():
  ck(re.fullmatch('[0-9a-f]{64}',r['proofSha256']),'proof digest');cl=r['classification'];ac=r['account'];counts[cl]+=1
  if cl=='AUTHENTICATED_ABSENT':ck(ac is None,'absence fields')
  else:
   ck(cl=='AUTHENTICATED_NONMATCH' and re.fullmatch('0x[0-9a-f]{64}',ac['codeHash']) and ac['codeHash']!=TARGET,'nonmatch');balance+=int(ac['balanceWei'])
 ck(dict(counts)==e['counts']=={'AUTHENTICATED_ABSENT':3,'AUTHENTICATED_NONMATCH':5973} and not e['newExactMatches'] and not e['exactMatches'],'classification totals')
 ck(all(e[k]==p['context'][k] for k in ('canonicality','completeness','eligibility')),'research scope')
 records=sorted([{'address':a,'kind':'PRIOR_RESEARCH_WALLET','evidence':r} for a,r in known.items()]+[{'address':a,'kind':'BOUNDED_EXCLUSION','evidence':r} for a,r in excluded.items()],key=lambda r:r['address'])
 context={'schema':'ppcr-v24.0b3f6-research-v1','scope':'RESEARCH_EVIDENCE_ONLY','chainId':1,'referenceBlock':4501968,'referenceRoot':ROOT,'targetCodeHash':TARGET,'recordCount':len(records),'knownCount':585,'exclusionCount':5976,'exclusionCounts':dict(counts),'excludedBalanceWei':str(balance),'priorCommitment':PRIOR,'priorTreeRoot':p['treeRoot'],'priorContext':p['context'],'positiveControl':control,'inputSha256':PINS,'proofReplayReportNodeOccurrences':e['proofNodeOccurrences'],'discoveryInterval':[4500969,4501968],'canonicality':'NOT_ATTESTED','completeness':'NOT_ESTABLISHED','eligibility':'NOT_DETERMINED','authorization':'NOT_DETERMINED','crossProviderValidation':'DEFERRED','verificationScope':'DECODED_REPORT_RECONCILIATION_AND_MERKLE_MEMBERSHIP_NOT_RAW_TRIE_REPLAY'}
 m.DOMAIN=DOMAIN
 n=len(records);size=1<<(n-1).bit_length();levels=[[m.leaf(i,r) for i,r in enumerate(records)]+[m.pad(i) for i in range(n,size)]]
 while len(levels[-1])>1:
  l=levels[-1];levels.append([m.branch(l[i],l[i+1]) for i in range(0,len(l),2)])
 root=levels[-1][0];cm=m.envelope(context,root);proofs=[]
 for i,r in enumerate(records):
  proof={'address':r['address'],'index':i,'siblings':[l[(i>>j)^1].hex() for j,l in enumerate(levels[:-1])]};ck(m.verify(r,proof,context,root,cm),'new membership');proofs.append(proof)
 tests=0
 for kind in ('PRIOR_RESEARCH_WALLET','BOUNDED_EXCLUSION'):
  i=next(i for i,r in enumerate(records) if r['kind']==kind);r=records[i];pr=proofs[i]
  def reject(rr=r,pp=pr,cc=context,rt=root,commit=cm):
   nonlocal tests
   ck(not m.verify(rr,pp,cc,rt,commit),'tamper accepted');tests+=1
  for key,value in [('kind','OTHER'),('address','0x'+'0'*40),('evidence',{})]:
   x=copy.deepcopy(r);x[key]=value;reject(rr=x)
  for key,value in [('index',-1),('index',n),('index',(i+1)%n),('siblings',pr['siblings'][:-1]),('siblings',['00'*32]+pr['siblings'][1:]),('address','OTHER')]:
   x=copy.deepcopy(pr);x[key]=value;reject(pp=x)
  for key,value in [('referenceRoot','0x'+'0'*64),('eligibility','ELIGIBLE'),('recordCount',n-1),('priorCommitment','0'*64),('targetCodeHash','0x'+'0'*64)]:
   x=copy.deepcopy(context);x[key]=value;reject(cc=x)
  reject(rt=bytes(32));reject(commit=bytes(32))
 report={'status':'PASS_RESEARCH_COMMITMENT','scope':context['scope'],'recordCount':n,'priorMembershipProofsVerified':585,'membershipProofsVerified':n,'treeLeaves':size,'paddingLeaves':size-n,'proofDepth':(n-1).bit_length(),'negativeTestsPassed':tests,'treeRoot':root.hex(),'commitment':cm.hex(),'context':context,'rpcRequests':0}
 for name,obj in [('ppcr_v24_0b3f6_report.json',report),('ppcr_v24_0b3f6_bundle.json',{'context':context,'treeRoot':root.hex(),'commitment':cm.hex(),'records':records,'proofs':proofs})]:
  (BASE/name).write_bytes(m.canon(obj)+b'\n')
 print('PASS_RESEARCH_COMMITMENT',n,tests,cm.hex(),flush=True);print('TREE_ROOT',root.hex(),flush=True)
if __name__=='__main__':main()
