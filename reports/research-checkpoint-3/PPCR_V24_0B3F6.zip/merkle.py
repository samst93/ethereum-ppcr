"""Research-only evidence commitment; Python standard library; no network."""
import hashlib,json,re,copy
from pathlib import Path
from collections import Counter,defaultdict
BASE=Path(__file__).resolve().parent
DOMAIN=b'PPCR-V23.5-RESEARCH-V1\0'
ROOTS={'pre':'0xb1f01f4c02cf90ffb4011de01da52c6681255654c8767f5b999c65fe1a61a53b','post':'0xbbe30a4416aa0f5ddc3d61e56b670565f6174513df3fb24525f7e2a5a7da9e1b','later':'0x59e252211d43a01f10a6d9e18dc94f7218a0dff7a9776fa70a67ac744c233bf4'}
def ck(x,msg):
 if not x: raise ValueError(msg)
def unique(pairs):
 d={}
 for k,v in pairs:
  ck(k not in d,'duplicate JSON key');d[k]=v
 return d
def valid(x):
 if isinstance(x,str):ck(all(32<=ord(c)<=126 for c in x),'nonprintable/nonASCII string')
 elif type(x) is int:ck(x>=0,'negative numeric token')
 elif x is None or type(x) is bool:pass
 elif isinstance(x,list):
  for v in x:valid(v)
 elif isinstance(x,dict):
  for k,v in x.items():valid(k);valid(v)
 else:raise ValueError('unsupported JSON type')
def canon(x):
 valid(x);return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def h(b):return hashlib.sha256(b).digest()
def u(n):return n.to_bytes(8,'big')
def leaf(i,r):
 b=canon(r);return h(DOMAIN+b'\0'+u(i)+u(len(b))+b)
def branch(l,r):return h(DOMAIN+b'\1'+l+r)
def pad(i):return h(DOMAIN+b'\2'+u(i))
def envelope(c,root):
 b=canon(c);return h(DOMAIN+b'\3'+u(len(b))+b+root)
def verify(r,p,c,root,commit):
 try:
  i=p['index'];n=c['recordCount'];ck(type(i) is int and 0<=i<n,'index');ck(p['address']==r['address'],'address');ck(len(p['siblings'])==(n-1).bit_length(),'depth');v=leaf(i,r)
  for s in p['siblings']:
   ck(re.fullmatch('[0-9a-f]{64}',s),'sibling');b=bytes.fromhex(s);v=branch(b,v) if i&1 else branch(v,b);i//=2
  return v==root and envelope(c,root)==commit
 except (ValueError,KeyError,TypeError,OverflowError):return False
