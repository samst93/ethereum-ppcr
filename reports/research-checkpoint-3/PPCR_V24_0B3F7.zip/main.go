package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"os"
	"regexp"
	"sort"
)

type M = map[string]any

const prior = "e6840ccdc8bbd61222c3f074065196e3c97000d757c4452aa1c24e105cc97e5c"
const target = "0x5d85058ca470c3561426ba7b1675197b2aa848173843dc79d36e3ec14ce91eeb"
const root = "0xb1f01f4c02cf90ffb4011de01da52c6681255654c8767f5b999c65fe1a61a53b"
const expected = "f175f915f02c733eebdc74795ed1cf95c7fb029c6e984090bef12ed00669aa35"
const expectedRoot = "bb2de28c6f946f8210673ef6769db13a456f591ee7dded0b7814f7f8527a7849"

var pins = M{"discovery.json": "675a969afe4448b2a6a4dc798028a45f7ab13222a1f160cc0eabc149c8ab4517", "exclusions.json": "7980d238c28e0f00cf243ef4781776f59879d4d3406d38c85b04e3ae19793904", "population.json": "60d961847b9ac488069f341fd78655a4fea262a330fb3b1e9e654b41a106402d", "prior.json": "f562287160c93ad7b855dd001a01c78086cfd568b2ba3c8a01e07043663657cd"}

func ck(b bool, s string) {
	if !b {
		panic(s)
	}
}
func obj(v any) M           { return v.(M) }
func arr(v any) []any       { return v.([]any) }
func str(v any) string      { return v.(string) }
func num(n int) json.Number { return json.Number(fmt.Sprint(n)) }
func ascii(s string) {
	for _, c := range s {
		ck(c >= 32 && c <= 126, "nonprintable ASCII")
	}
}

var digits = regexp.MustCompile(`^(0|[1-9][0-9]*)$`)
var addr = regexp.MustCompile(`^0x[0-9a-f]{40}$`)
var digest = regexp.MustCompile(`^[0-9a-f]{64}$`)

func token(d *json.Decoder) any {
	t, e := d.Token()
	ck(e == nil, "JSON token")
	switch v := t.(type) {
	case json.Delim:
		if v == '{' {
			m := M{}
			for d.More() {
				k := str(token(d))
				_, ok := m[k]
				ck(!ok, "duplicate key")
				m[k] = token(d)
			}
			t, e = d.Token()
			ck(e == nil && t == json.Delim('}'), "object end")
			return m
		}
		ck(v == '[', "array start")
		a := []any{}
		for d.More() {
			a = append(a, token(d))
		}
		t, e = d.Token()
		ck(e == nil && t == json.Delim(']'), "array end")
		return a
	case string:
		ascii(v)
	case json.Number:
		ck(digits.MatchString(string(v)), "number")
	case bool, nil:
	default:
		panic("type")
	}
	return t
}
func parse(b []byte) any {
	d := json.NewDecoder(bytes.NewReader(b))
	d.UseNumber()
	v := token(d)
	_, e := d.Token()
	ck(e == io.EOF, "trailing JSON")
	return v
}
func canon(v any) []byte {
	var b bytes.Buffer
	e := json.NewEncoder(&b)
	e.SetEscapeHTML(false)
	ck(e.Encode(v) == nil, "encode")
	return bytes.TrimSuffix(b.Bytes(), []byte("\n"))
}
func equal(a, b any) bool  { return bytes.Equal(canon(a), canon(b)) }
func hash(b []byte) string { return fmt.Sprintf("%x", sha256.Sum256(b)) }
func load(n string) M {
	b, e := os.ReadFile(n)
	ck(e == nil, n)
	if p, ok := pins[n]; ok {
		ck(hash(b) == p, n+" pin")
	}
	return obj(parse(b))
}
func u(i int) []byte { b := make([]byte, 8); binary.BigEndian.PutUint64(b, uint64(i)); return b }
func h(d string, t byte, parts ...[]byte) []byte {
	v := sha256.New()
	v.Write([]byte(d))
	v.Write([]byte{0, t})
	for _, p := range parts {
		v.Write(p)
	}
	return v.Sum(nil)
}
func leaf(d string, i int, r any) []byte { b := canon(r); return h(d, 0, u(i), u(len(b)), b) }
func env(d string, c M, r []byte) string {
	b := canon(c)
	return hex.EncodeToString(h(d, 3, u(len(b)), b, r))
}
func hx(b []byte) string { return hex.EncodeToString(b) }
func tree(d string, rs []any) ([][][]byte, int) {
	n := 1
	for n < len(rs) {
		n *= 2
	}
	l := make([][]byte, n)
	for i := range l {
		if i < len(rs) {
			l[i] = leaf(d, i, rs[i])
		} else {
			l[i] = h(d, 2, u(i))
		}
	}
	ls := [][][]byte{l}
	for len(l) > 1 {
		q := make([][]byte, len(l)/2)
		for i := range q {
			q[i] = h(d, 1, l[2*i], l[2*i+1])
		}
		ls = append(ls, q)
		l = q
	}
	return ls, n
}
func verify(d string, r, p, c M, rt, cm string) (ok bool) {
	defer func() {
		if recover() != nil {
			ok = false
		}
	}()
	i, e := p["index"].(json.Number).Int64()
	n, e2 := c["recordCount"].(json.Number).Int64()
	if e != nil || e2 != nil || i < 0 || i >= n || p["address"] != r["address"] {
		return false
	}
	depth := 0
	for x := n - 1; x > 0; x >>= 1 {
		depth++
	}
	ss := arr(p["siblings"])
	if len(ss) != depth {
		return false
	}
	v := leaf(d, int(i), r)
	for _, s := range ss {
		a := str(s)
		if !digest.MatchString(a) {
			return false
		}
		b, _ := hex.DecodeString(a)
		if i&1 == 1 {
			v = h(d, 1, b, v)
		} else {
			v = h(d, 1, v, b)
		}
		i >>= 1
	}
	return hx(v) == rt && env(d, c, v) == cm
}
func index(rs []any) map[string]M {
	m := map[string]M{}
	for _, v := range rs {
		r := obj(v)
		a := str(r["address"])
		ck(addr.MatchString(a) && m[a] == nil, "address duplicate or invalid")
		m[a] = r
	}
	return m
}
func checkset(a []any, m map[string]M) {
	ck(len(a) == len(m), "set size")
	seen := map[string]bool{}
	for _, v := range a {
		s := str(v)
		ck(m[s] != nil && !seen[s], "set membership")
		seen[s] = true
	}
}
func checktree(d string, rs, ps []any, c M, rt, cm string) int {
	ck(len(rs) == len(ps) && c["recordCount"] == num(len(rs)), "proof coverage")
	index(rs)
	pm := index(ps)
	ls, n := tree(d, rs)
	r := ls[len(ls)-1][0]
	ck(hx(r) == rt && env(d, c, r) == cm, "reconstructed root/envelope")
	last := ""
	for i, v := range rs {
		a := str(obj(v)["address"])
		ck(a > last, "sort")
		last = a
		p := pm[a]
		ck(p != nil && p["index"] == num(i) && verify(d, obj(v), p, c, rt, cm), "membership")
		for j, s := range arr(p["siblings"]) {
			ck(s == hx(ls[j][(i>>j)^1]), "path mismatch")
		}
	}
	return n
}
func clone(m M) M { return obj(parse(canon(m))) }
func main() {
	defer func() {
		if x := recover(); x != nil {
			fmt.Fprintln(os.Stderr, "FAIL", x)
			os.Exit(1)
		}
	}()
	p := load("prior.json")
	e := load("exclusions.json")
	d := load("discovery.json")
	pop := load("population.json")
	b := load("ppcr_v24_0b3f6_bundle.json")
	pc := obj(p["context"])
	ck(p["commitment"] == prior && obj(pc["roots"])["pre"] == root, "prior anchor")
	known := index(arr(p["records"]))
	ck(len(known) == 585, "known size")
	checktree("PPCR-V23.5-RESEARCH-V1", arr(p["records"]), arr(p["proofs"]), pc, str(p["treeRoot"]), prior)
	ck(e["referenceRoot"] == root && e["referenceBlock"] == num(4501968) && e["targetCodeHash"] == target && e["status"] == "PASS_OFFLINE_AUTHENTICATED_POPULATION", "reference")
	ck(e["populationSha256"] == pins["population.json"] && pop["discoverySha256"] == pins["discovery.json"], "provenance")
	ex := map[string]M{}
	var control M
	abs, non := 0, 0
	balance := new(big.Int)
	for a, r := range index(arr(e["rows"])) {
		ck(digest.MatchString(str(r["proofSha256"])), "proof digest")
		if r["control"] == true {
			ck(control == nil && known[a] != nil && r["classification"] == "EXACT_RUNTIME_MATCH" && equal(r["account"], obj(arr(known[a]["snapshots"])[0])["account"]), "control")
			control = r
			continue
		}
		ck(r["control"] == false && known[a] == nil, "disjoint")
		ex[a] = r
		if r["classification"] == "AUTHENTICATED_ABSENT" {
			ck(r["account"] == nil, "absence")
			abs++
		} else {
			ac := obj(r["account"])
			ch := str(ac["codeHash"])
			ck(r["classification"] == "AUTHENTICATED_NONMATCH" && len(ch) == 66 && ch[:2] == "0x" && digest.MatchString(ch[2:]) && ch != target, "nonmatch")
			s := str(ac["balanceWei"])
			ck(digits.MatchString(s), "balance")
			v, ok := new(big.Int).SetString(s, 10)
			ck(ok, "balance parse")
			balance.Add(balance, v)
			non++
		}
	}
	ck(control != nil && len(ex) == 5976 && abs == 3 && non == 5973, "counts")
	counts := M{"AUTHENTICATED_ABSENT": num(abs), "AUTHENTICATED_NONMATCH": num(non)}
	ck(equal(counts, e["counts"]) && len(arr(e["exactMatches"])) == 0 && len(arr(e["newExactMatches"])) == 0, "reported counts")
	checkset(arr(d["addresses"]), ex)
	checkset(arr(pop["addresses"]), ex)
	checkset(arr(pop["known"]), known)
	for _, k := range []string{"canonicality", "completeness", "eligibility"} {
		ck(e[k] == pc[k], "scope")
	}
	rs := []any{}
	for a, r := range known {
		rs = append(rs, M{"address": a, "kind": "PRIOR_RESEARCH_WALLET", "evidence": r})
	}
	for a, r := range ex {
		rs = append(rs, M{"address": a, "kind": "BOUNDED_EXCLUSION", "evidence": r})
	}
	sort.Slice(rs, func(i, j int) bool { return str(obj(rs[i])["address"]) < str(obj(rs[j])["address"]) })
	c := M{"schema": "ppcr-v24.0b3f6-research-v1", "scope": "RESEARCH_EVIDENCE_ONLY", "chainId": num(1), "referenceBlock": num(4501968), "referenceRoot": root, "targetCodeHash": target, "recordCount": num(len(rs)), "knownCount": num(585), "exclusionCount": num(5976), "exclusionCounts": counts, "excludedBalanceWei": balance.String(), "priorCommitment": prior, "priorTreeRoot": p["treeRoot"], "priorContext": pc, "positiveControl": control, "inputSha256": pins, "proofReplayReportNodeOccurrences": e["proofNodeOccurrences"], "discoveryInterval": []any{num(4500969), num(4501968)}, "canonicality": "NOT_ATTESTED", "completeness": "NOT_ESTABLISHED", "eligibility": "NOT_DETERMINED", "authorization": "NOT_DETERMINED", "crossProviderValidation": "DEFERRED", "verificationScope": "DECODED_REPORT_RECONCILIATION_AND_MERKLE_MEMBERSHIP_NOT_RAW_TRIE_REPLAY"}
	ck(equal(c, b["context"]) && equal(rs, b["records"]) && b["commitment"] == expected && b["treeRoot"] == expectedRoot, "bundle reconstruction")
	domain := "PPCR-V24.0B3F6-RESEARCH-V1"
	ps := arr(b["proofs"])
	n := checktree(domain, rs, ps, c, expectedRoot, expected)
	tests := 0
	for _, kind := range []string{"PRIOR_RESEARCH_WALLET", "BOUNDED_EXCLUSION"} {
		for i, v := range rs {
			r := obj(v)
			if r["kind"] != kind {
				continue
			}
			pr := obj(ps[i])
			reject := func(rr, pp, cc M, rt, cm string) {
				ck(!verify(domain, rr, pp, cc, rt, cm), "tampering accepted")
				tests++
			}
			for k, val := range (M{"kind": "OTHER", "address": "0x0000000000000000000000000000000000000000", "evidence": M{}}) {
				x := clone(r)
				x[k] = val
				reject(x, pr, c, expectedRoot, expected)
			}
			for k, val := range (M{"index": num(-1), "address": "OTHER", "siblings": []any{}}) {
				x := clone(pr)
				x[k] = val
				reject(r, x, c, expectedRoot, expected)
			}
			for _, j := range []int{len(rs), (i + 1) % len(rs)} {
				x := clone(pr)
				x["index"] = num(j)
				reject(r, x, c, expectedRoot, expected)
			}
			x := clone(pr)
			arr(x["siblings"])[0] = fmt.Sprintf("%064d", 0)
			reject(r, x, c, expectedRoot, expected)
			for k, val := range (M{"referenceRoot": "OTHER", "eligibility": "ELIGIBLE", "recordCount": num(len(rs) - 1), "priorCommitment": "OTHER", "targetCodeHash": "OTHER"}) {
				x := clone(c)
				x[k] = val
				reject(r, pr, x, expectedRoot, expected)
			}
			reject(r, pr, c, "OTHER", expected)
			reject(r, pr, c, expectedRoot, "OTHER")
			break
		}
	}
	report := M{"status": "PASS_INDEPENDENT_GO_COMMITMENT", "scope": "RESEARCH_EVIDENCE_ONLY", "recordCount": len(rs), "priorMembershipProofsVerified": 585, "membershipProofsVerified": len(rs), "negativeTestsPassed": tests, "treeLeaves": n, "paddingLeaves": n - len(rs), "proofDepth": 13, "treeRoot": expectedRoot, "commitment": expected, "rpcRequests": 0, "verificationScope": c["verificationScope"], "canonicality": c["canonicality"], "completeness": c["completeness"], "eligibility": c["eligibility"]}
	ck(os.WriteFile("ppcr_v24_0b3f7_report.json", append(canon(report), '\n'), 0644) == nil, "report write")
	fmt.Println("PASS_INDEPENDENT_GO_COMMITMENT", len(rs), tests, expected)
}
