PPCR V24.0B3F7: independent Go research commitment verifier
Run from this directory: go run main.go (Go 1.23 or later recommended).
Alternatively run ppcr_f7.exe on Windows amd64. No network or dependencies.
The program reconstructs both Merkle trees, verifies all paths against rebuilt trees, checks four pinned source files, reconstructs the F6 records and context, and rejects 32 altered membership inputs. It checks printable ASCII JSON and nonnegative integer tokens at input, with duplicate keys rejected. It does not replay Ethereum trie proofs or establish canonicality, completeness, or eligibility. The Windows executable is cross-compiled, not executed on Windows here. The source was executed with Go 1.23.2 Linux amd64.
Delete any previous ppcr_v24_0b3f7_report.json before execution and require exit code zero. The report is generated only after all checks pass.
